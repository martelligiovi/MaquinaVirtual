#!/bin/bash

carpeta_origen=$1
carpeta_destino=$2
nombre=$3
fecha=$(date "+%Y%m%d")


# Definir una función para enviar correos con el log usando mutt
enviar_correo() {
    local asunto="$1"
    local cuerpo="$2"
    echo "$cuerpo" | mutt -s "$asunto" root
}

if [[ "$carpeta_origen" == "-h" ]]; then
	echo "este script se usa para hacer backups, se pasa por parametro la carpeta de origen, la carpeta de destino y nombre del directorio, en ese orden"
else
	if [ -d "$carpeta_origen" ]; then
		if [ -d "$carpeta_destino" ]; then
			tar -cf "${nombre}_bkp_${fecha}.tar" "$carpeta_origen"
			gzip "${nombre}_bkp_${fecha}.tar"
			mv "${nombre}_bkp_${fecha}.tar.gz" "$carpeta_destino"
			enviar_correo "Respaldo de $nombre" "Respaldo de $carpeta_origen finalizado."
			echo "respaldo de ${carpeta} finalizado"
		else
			mensaje="Error: $carpeta_destino no está montado"
			enviar_correo "Error en respaldo" "$mensaje"
            		echo "$mensaje"
		fi
	else
		mensaje="Error: $carpeta_origen no existe"
        	enviar_correo "Error en respaldo" "$mensaje"
        	echo "$mensaje"
	fi
fi
