#!/bin/bash

uso() {
    echo "Uso: ./esLaborable.sh [fecha en formato MM/DD]" 
}

if [ -z "$1" ]; then 
    # Verificar si se le dio un argumento
    uso
    exit 1
fi

esLaborable() {
    local fecha=$1
    local dia_semana=$(date -d "$fecha" +%u)  # Toma el dia de la semana que cae
    local fecha_mmdd=$(date -d "$fecha" +%m/%d) # Toma el formato de fecha a MM/DD
    local feriados="feriados" # Toma los datos del archivo de feriados    

    if [ $dia_semana -ge 6 ]; then # Verifica si es fin de semana (sábado o domingo)
        echo "No laborable: Es fin de semana."
        return 0
    fi

    if grep -q "$fecha_mmdd" "$feriados"; then # Verifica si está en la lista de feriados
        echo "No laborable: Es un feriado."
        if [ "$fecha_mmdd" = "06/17" ] || [ "$fecha_mmdd" = "08/17" ] || [ "$fecha_mmdd" = "10/12" ] || [ "$fecha_mmdd" = "11/20" ]; then
            if [ $dia_semana -ge 4 ]; then
                echo "Este feriado se deberia pasar para el lunes que viene"
                return 0
            elif [ $dia_semana -le 2 ]; then
                echo "Este feriado se deberia pasar para el lunes anterior"
                return 0
            fi
        fi
        return 0
    fi
    
    echo "Laborable" # Si no es fin de semana ni feriado, es laborable
    return 1
}

# Llama a la función principal
esLaborable "$1"
