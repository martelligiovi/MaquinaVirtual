# Verifica que se pase un argumento (nombre del proceso) al script
if [ $# -ne 1 ]; then
	echo "Uso: $0 <nombre_del_proceso>"
	exit 1
fi

proceso="$1"

# Comprueba si el proceso esta en ejecucion
if pgrep -x "$proceso" >/dev/null; then
	echo "El proceso $proceso esta en ejecucion"  # lo manda a la papelera
else
	# Define el contenido del correo
	email_subject="Alerta: Proceso $proceso no esta en ejecucion"
	email_body="El proceso $proceso no esta en ejecucion"
	# Utilizo mutt para enviar el correo (con -s)
	echo "$email_body" | mutt -s "$email_subject" root
	# Confirma el mail
	echo "El proceso $proceso no esta en ejecion. Correo enviado a root"
fi
