#!/bin/bash

if [ $# -ne 1 ]; then
    echo "Uso: $0 [fecha en formato MM/DD]"
    exit 1
fi

fecha="$1"
resultado=$(./esLaborable.sh "$fecha")

echo "Fecha: $fecha"
echo "Resultado: $resultado"


